﻿namespace ARS_API.DTOs
{
    public class UpdateUserDto
    {
        public string NewEmail { get; set; }
        public string NewPassword { get; set; }
    }
}
